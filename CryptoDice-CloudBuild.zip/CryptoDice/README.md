# Crypto Dice — bulle flottante Android

Application Android minimaliste avec une bulle flottante déplaçable. Un toucher ouvre un panneau contenant trois dés à six faces, un bouton RELANCER et le total.

## Aléatoire
Chaque dé est tiré indépendamment avec `java.security.SecureRandom.nextInt(6) + 1`. `nextInt(6)` utilise un tirage borné sans biais modulo. Aucun accès réseau n'est utilisé.

## Autorisations Android
- Affichage par-dessus les autres applications (`SYSTEM_ALERT_WINDOW`) pour la bulle.
- Service au premier plan de type `specialUse` afin que la bulle puisse rester active lorsque l'application passe en arrière-plan. Android affiche une notification persistante avec une action Arrêter.
- Notification (Android 13 et plus).

## Compiler sans ordinateur avec GitHub Actions
1. Sur le téléphone, crée un compte GitHub si nécessaire et crée un dépôt vide nommé `crypto-dice`.
2. Téléverse le fichier `CryptoDice-CloudBuild.zip` à la racine du dépôt (ne le décompresse pas).
3. Dans GitHub, choisis **Add file > Create new file**.
4. Nomme le fichier `.github/workflows/build.yml`.
5. Copie le contenu du fichier `build.yml` fourni à côté de cette archive, puis valide le commit.
6. Ouvre l'onglet **Actions** du dépôt. Le workflow **Build Crypto Dice APK** compile l'application dans le cloud.
7. Quand l'exécution est terminée (coche verte), ouvre-la et télécharge l'artefact `CryptoDice-debug-apk`.
8. Décompresse l'artefact sur le téléphone et installe `app-debug.apk`.

## Premier lancement
1. Ouvre Crypto Dice.
2. Appuie sur **ACTIVER LA BULLE**.
3. Android ouvre l'autorisation « Afficher par-dessus les autres applications » : autorise Crypto Dice.
4. Reviens dans l'application et appuie de nouveau sur **ACTIVER LA BULLE**.
5. La bulle 🎲 apparaît. Touche-la pour afficher les trois dés. Fais-la glisser pour la déplacer.

Pour arrêter, utilise le bouton **DÉSACTIVER LA BULLE** dans l'application ou l'action Arrêter de la notification.

## Configuration technique
- Android Gradle Plugin 8.9.2
- Kotlin Android plugin 2.1.10
- Gradle 8.11.1
- JDK 17
- compileSdk / targetSdk 35 ; minSdk 23
