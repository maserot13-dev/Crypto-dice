plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "fr.cryptodice.widget"
    compileSdk = 35
    defaultConfig {
        applicationId = "fr.cryptodice.widget"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
