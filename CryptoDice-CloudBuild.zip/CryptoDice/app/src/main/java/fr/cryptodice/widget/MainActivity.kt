package fr.cryptodice.widget

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(Color.rgb(15, 18, 25))
        }
        val title = TextView(this).apply {
            text = "🎲  CRYPTO DICE"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Trois dés à six faces, dans une bulle flottante au-dessus de tes applications.\n\nTirages indépendants avec SecureRandom. Fonctionne hors connexion."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 28)
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(180, 210, 190))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        val start = Button(this).apply {
            text = "ACTIVER LA BULLE"
            setOnClickListener { enableBubble() }
        }
        val stop = Button(this).apply {
            text = "DÉSACTIVER LA BULLE"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingDiceService::class.java)); updateStatus() }
        }
        root.addView(title)
        root.addView(info)
        root.addView(status)
        root.addView(start, LinearLayout.LayoutParams(-1, -2))
        root.addView(stop, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status.text = "Autorise Crypto Dice à s'afficher par-dessus les autres applications, puis reviens ici."
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
        val intent = Intent(this, FloatingDiceService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        status.text = "Bulle activée. Tu peux revenir à tes applications."
    }

    private fun updateStatus() {
        status.text = if (Settings.canDrawOverlays(this)) {
            "Autorisation de bulle accordée. Appuie sur Activer pour afficher le dé."
        } else {
            "Une autorisation Android sera demandée au premier lancement."
        }
    }
}
