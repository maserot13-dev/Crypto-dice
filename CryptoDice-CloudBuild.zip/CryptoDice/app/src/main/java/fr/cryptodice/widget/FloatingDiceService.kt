package fr.cryptodice.widget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.security.SecureRandom
import kotlin.math.abs

class FloatingDiceService : Service() {
    companion object {
        private const val CHANNEL_ID = "crypto_dice_overlay"
        private const val NOTIFICATION_ID = 7301
        private const val ACTION_STOP = "fr.cryptodice.widget.STOP_FLOATING_DICE"
        private val rng = SecureRandom()
        private val faces = arrayOf("⚀", "⚁", "⚂", "⚃", "⚄", "⚅")
        private fun roll() = rng.nextInt(6) + 1
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var diceText: TextView? = null
    private var totalText: TextView? = null
    private var values = listOf(1, 1, 1)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        val stopIntent = Intent(this, FloatingDiceService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openIntent = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Crypto Dice actif")
                .setContentText("La bulle de dés est affichée. Appuie ici pour les réglages.")
                .setContentIntent(openIntent)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", stopPending)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Crypto Dice actif")
                .setContentText("La bulle de dés est affichée.")
                .setContentIntent(openIntent)
                .setOngoing(true)
                .build()
        }
        startForeground(NOTIFICATION_ID, notification)
        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Bulle Crypto Dice", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    @Suppress("DEPRECATION")
    private fun overlayParams(width: Int, height: Int, gravity: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity; x = dp(12); y = dp(180) }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "🎲"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(35, 105, 220), 50)
            elevation = dp(8).toFloat()
            contentDescription = "Ouvrir Crypto Dice"
        }
        val bp = overlayParams(dp(58), dp(58), Gravity.TOP or Gravity.START)
        bubble = b
        bubbleParams = bp
        b.setOnTouchListener(BubbleTouchListener())
        wm.addView(b, bp)
    }

    private inner class BubbleTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = bubbleParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y; touchX = event.rawX; touchY = event.rawY; moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) + abs(dy) > dp(5)) moved = true
                    p.x = startX + dx; p.y = startY + dy
                    wm.updateViewLayout(v, p)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    return true
                }
            }
            return false
        }
    }

    private fun togglePanel() {
        if (panel != null) {
            try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
            panel = null
        } else showPanel()
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(24, 29, 40), 22)
            elevation = dp(12).toFloat()
        }
        val heading = TextView(this).apply {
            text = "CRYPTO DICE"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        diceText = TextView(this).apply {
            textSize = 38f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(2))
        }
        totalText = TextView(this).apply {
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, dp(8))
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val rollButton = Button(this).apply {
            text = "RELANCER"
            isAllCaps = false
            setOnClickListener { rollDice() }
        }
        val closeButton = Button(this).apply {
            text = "FERMER"
            isAllCaps = false
            setOnClickListener { togglePanel() }
        }
        buttons.addView(rollButton, LinearLayout.LayoutParams(0, dp(44), 1f))
        buttons.addView(closeButton, LinearLayout.LayoutParams(0, dp(44), 1f))
        box.addView(heading)
        box.addView(diceText)
        box.addView(totalText)
        box.addView(buttons)
        val pp = overlayParams(dp(260), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        val bp = bubbleParams
        if (bp != null) {
            pp.x = bp.x
            pp.y = bp.y + dp(66)
        }
        panel = box
        panelParams = pp
        wm.addView(box, pp)
        rollDice()
    }

    private fun rollDice() {
        values = listOf(roll(), roll(), roll())
        diceText?.text = values.joinToString("      ") { faces[it - 1] }
        totalText?.text = "Total : ${values.sum()} / 18"
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null; panel = null
        @Suppress("DEPRECATION")
        stopForeground(true)
        super.onDestroy()
    }
}
